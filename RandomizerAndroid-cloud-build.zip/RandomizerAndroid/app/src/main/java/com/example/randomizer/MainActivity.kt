package com.example.randomizer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private val Night = Color(0xFF100D28)
private val Panel = Color(0xFF1B1740)
private val Purple = Color(0xFF9A55FF)
private val Pink = Color(0xFFFF79D7)
private val Lavender = Color(0xFFD7C7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { RandomizerApp() }
    }
}

@Composable
fun RandomizerApp() {
    var result by remember { mutableIntStateOf(7) }
    var rolling by remember { androidx.compose.runtime.mutableStateOf(false) }
    var spinCount by remember { mutableIntStateOf(0) }
    val history = remember { mutableStateListOf(4, 11, 3, 9, 7, 12, 5, 8, 2, 10) }
    val rotation by animateFloatAsState(
        targetValue = spinCount * 360f,
        animationSpec = tween(durationMillis = 850, easing = FastOutSlowInEasing),
        label = "diceRotation"
    )
    val scale by animateFloatAsState(
        targetValue = if (rolling) 1.12f else 1f,
        animationSpec = tween(300), label = "diceScale"
    )

    MaterialTheme {
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF17113B), Night, Color(0xFF09091C)))
            )
        ) {
            // Subtle decorative stars
            Canvas(Modifier.fillMaxSize()) {
                val dots = listOf(
                    Offset(size.width * .12f, size.height * .16f), Offset(size.width * .84f, size.height * .11f),
                    Offset(size.width * .72f, size.height * .36f), Offset(size.width * .18f, size.height * .57f),
                    Offset(size.width * .91f, size.height * .68f), Offset(size.width * .42f, size.height * .82f)
                )
                dots.forEachIndexed { i, p -> drawCircle(Pink.copy(alpha = if (i % 2 == 0) .7f else .35f), radius = 2.5f, center = p) }
            }
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("✧", color = Pink, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Рандомайзер", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Случайное число до 12", color = Lavender, fontSize = 14.sp)
                    }
                    Text("⚙", color = Lavender, fontSize = 25.sp)
                }

                Spacer(Modifier.height(18.dp))
                Surface(
                    color = Panel.copy(alpha = .92f),
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Purple.copy(alpha = .65f), RoundedCornerShape(28.dp))
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            Mascot(Modifier.size(142.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (rolling) "Бросаю!" else "Удачи! ♡", color = Pink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(10.dp))
                                Box(Modifier.size(94.dp).scale(scale).rotate(rotation), contentAlignment = Alignment.Center) {
                                    DiceFace(result)
                                }
                                Text("Твой счастливый кубик", color = Lavender, fontSize = 11.sp, textAlign = TextAlign.Center)
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("ВЫПАЛО ЧИСЛО", color = Lavender, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
                        AnimatedContent(targetState = result, label = "result") { number ->
                            Text(number.toString(), color = Color.White, fontSize = 76.sp, fontWeight = FontWeight.Black)
                        }
                        Button(
                            onClick = {
                                if (!rolling) {
                                    rolling = true
                                    spinCount += 1
                                }
                            },
                            enabled = !rolling,
                            colors = ButtonDefaults.buttonColors(containerColor = Purple, disabledContainerColor = Purple.copy(alpha = .6f)),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier.fillMaxWidth().height(58.dp)
                        ) {
                            Text(if (rolling) "✦  Бросаем..." else "🎲  БРОСИТЬ КУБИК", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                        LaunchedEffect(rolling, spinCount) {
                            if (rolling) {
                                delay(850)
                                result = Random.nextInt(1, 13)
                                history.add(0, result)
                                while (history.size > 10) history.removeAt(history.lastIndex)
                                rolling = false
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Сбросить историю",
                            color = Lavender,
                            fontSize = 13.sp,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { history.clear() }.padding(8.dp)
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))
                Surface(
                    color = Color(0xFF15122F).copy(alpha = .94f), shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Purple.copy(alpha = .42f), RoundedCornerShape(22.dp))
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("◷", color = Pink, fontSize = 22.sp)
                            Spacer(Modifier.width(8.dp))
                            Text("Последние броски", color = Lavender, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.weight(1f))
                            Text("${history.size}/10", color = Purple, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        if (history.isEmpty()) {
                            Text("Здесь появятся твои результаты ✨", color = Lavender.copy(alpha = .75f), fontSize = 13.sp)
                        } else {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                itemsIndexed(history) { index, number ->
                                    Box(
                                        modifier = Modifier.size(43.dp).clip(RoundedCornerShape(13.dp))
                                            .background(if (index == 0) Purple.copy(alpha = .35f) else Panel)
                                            .border(1.dp, if (index == 0) Pink else Purple.copy(alpha = .5f), RoundedCornerShape(13.dp)),
                                        contentAlignment = Alignment.Center
                                    ) { Text(number.toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("✨  Пусть удача будет на твоей стороне!  ✨", color = Lavender.copy(alpha = .8f), fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun DiceFace(number: Int) {
    Box(Modifier.size(88.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRoundRect(
                brush = Brush.linearGradient(listOf(Color.White, Color(0xFFE4D7FF), Color(0xFFB99AFF))),
                size = Size(w * .86f, h * .86f), topLeft = Offset(w * .07f, h * .07f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * .18f)
            )
            drawRoundRect(color = Pink.copy(alpha = .8f), size = Size(w * .86f, h * .86f), topLeft = Offset(w * .07f, h * .07f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * .18f), style = Stroke(width = 3f))
        }
        Text(number.toString(), color = Color(0xFF5524A9), fontSize = 37.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun Mascot(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        // hair silhouette and twin side locks
        drawCircle(Color(0xFF272047), radius = w * .40f, center = Offset(w * .50f, h * .45f))
        drawOval(Color(0xFFB7A0FF), topLeft = Offset(w * .13f, h * .24f), size = Size(w * .74f, h * .62f))
        drawOval(Color(0xFFDFCFFF), topLeft = Offset(w * .22f, h * .23f), size = Size(w * .58f, h * .57f))
        // fringe
        val fringe = Path().apply {
            moveTo(w * .20f, h * .43f); quadraticTo(w * .19f, h * .12f, w * .48f, h * .17f)
            quadraticTo(w * .72f, h * .10f, w * .82f, h * .40f)
            lineTo(w * .67f, h * .34f); lineTo(w * .58f, h * .48f); lineTo(w * .48f, h * .34f)
            lineTo(w * .37f, h * .47f); lineTo(w * .29f, h * .35f); close()
        }
        drawPath(fringe, Color(0xFFC7B1FF))
        // face
        drawOval(Color(0xFFFFDCCF), topLeft = Offset(w * .29f, h * .34f), size = Size(w * .42f, h * .39f))
        // eyes
        drawOval(Color(0xFF7C42E8), topLeft = Offset(w * .37f, h * .48f), size = Size(w * .07f, h * .10f))
        drawOval(Color(0xFF7C42E8), topLeft = Offset(w * .56f, h * .48f), size = Size(w * .07f, h * .10f))
        drawCircle(Color.White, radius = w * .015f, center = Offset(w * .39f, h * .50f))
        drawCircle(Color.White, radius = w * .015f, center = Offset(w * .58f, h * .50f))
        // blush and smile
        drawCircle(Color(0xFFFF9EBD).copy(alpha = .75f), radius = w * .035f, center = Offset(w * .34f, h * .59f))
        drawCircle(Color(0xFFFF9EBD).copy(alpha = .75f), radius = w * .035f, center = Offset(w * .66f, h * .59f))
        val smile = Path().apply { moveTo(w * .45f, h * .61f); quadraticTo(w * .51f, h * .68f, w * .57f, h * .61f) }
        drawPath(smile, Color(0xFFB94B86), style = Stroke(width = w * .018f))
        // black ribbon
        drawCircle(Color(0xFF28203E), radius = w * .11f, center = Offset(w * .78f, h * .29f))
        val bow = Path().apply { moveTo(w * .75f, h * .27f); lineTo(w * .88f, h * .18f); lineTo(w * .86f, h * .34f); close() }
        drawPath(bow, Color(0xFF28203E))
        // shoulders / outfit
        drawOval(Color(0xFF28203E), topLeft = Offset(w * .20f, h * .76f), size = Size(w * .60f, h * .27f))
        drawArc(Pink, 205f, 130f, false, topLeft = Offset(w * .20f, h * .74f), size = Size(w * .60f, h * .25f), style = Stroke(width = w * .025f))
    }
}
